class @artifact.name@ {
	long timeout = 1000

	def execute() {	
	    // execute task
	}
}
