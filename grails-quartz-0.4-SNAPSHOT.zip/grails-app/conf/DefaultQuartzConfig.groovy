//
//
quartz {
    autoStartup = true
    jdbcStore = false
}
