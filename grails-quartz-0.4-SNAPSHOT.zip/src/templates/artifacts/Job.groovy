class @artifact.name@ {
	def timeout = 5000l     // execute job once in 5 seconds

    def execute() {
	    // execute task
	}
}
